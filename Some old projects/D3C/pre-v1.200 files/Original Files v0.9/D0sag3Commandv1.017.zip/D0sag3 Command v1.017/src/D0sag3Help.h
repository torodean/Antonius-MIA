/*
 * D0sag3Help.h
 *
 *  Created on: Oct 10, 2014
 *      Author: antonius
 */

#ifndef D0SAG3HELP_H_
#define D0SAG3HELP_H_

namespace std {

class D0sag3Help {
public:
	D0sag3Help();
	void helpRunner();
	void helpRunnerExtended();
	virtual ~D0sag3Help();
};

} /* namespace std */

#endif /* D0SAG3HELP_H_ */
